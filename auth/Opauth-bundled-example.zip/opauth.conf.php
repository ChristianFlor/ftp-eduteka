<?php
/**
 * Opauth basic configuration file to quickly get you started
 * ==========================================================
 * To use: rename to opauth.conf.php and tweak as you like
 * If you require advanced configuration options, refer to opauth.conf.php.advanced
 */

$config = array(
/**
 * Path where Opauth is accessed.
 *  - Begins and ends with /
 *  - eg. if Opauth is reached via http://example.org/auth/, path is '/auth/'
 *  - if Opauth is reached via http://auth.example.org/, path is '/'
 */
	'path' => '/auth/',

/**
 * Callback URL: redirected to after authentication, successful or otherwise
 */
	'callback_url' => '{path}callback.php',
	
/**
 * A random string used for signing of $auth response.
 * 
 * NOTE: PLEASE CHANGE THIS INTO SOME OTHER RANDOM STRING
 */
	'security_salt' => 'mimamamemimamemamedemimama',
		
/**
 * Strategy
 * Refer to individual strategy's documentation on configuration requirements.
 * 
 * eg.
 * 'Strategy' => array(
 * 
 *   'Facebook' => array(
 *      'app_id' => 'APP ID',
 *      'app_secret' => 'APP_SECRET'
 *    ),
 * 
 * )
 *
 */
	'Strategy' => array(
		'Facebook' => array(
						'app_id' => '269756146469636',
						'app_secret' => '903abfce0ed6809bb26299ce7d0c07c4'
					),
		'Google' => array(
						'client_id' => '957022413574.apps.googleusercontent.com',
						'client_secret' => 'vtdPNXa9qIcKWp-hjpFeiDaV'
					),
		'LinkedIn' => array(
						'api_key' => 'ynynzchq4995',
						'secret_key' => 'xUJMukRezSZZgOVJ'
					),
		'Twitter' => array(
						'key' => 'PGuDhDok6gYYCftTEfWoaA',
						'secret' => 'rIxN2lWWOTV4aPNmRC4emzUQ4PKNnc9634Sy948hs'
						
					)
		)
						
    );