<?php
/**
 * Callback for Opauth
 * 
 * This file (callback.php) provides an example on how to properly receive auth response of Opauth.
 * 
 * Basic steps:
 * 1. Fetch auth response based on callback transport parameter in config.
 * 2. Validate auth response
 * 3. Once auth response is validated, your PHP app should then work on the auth response 
 *    (eg. registers or logs user in to your site, save auth data onto database, etc.)
 * 
 */


/**
 * Define paths
 */
define('CONF_FILE', dirname(__FILE__).'/'.'opauth.conf.php');
define('OPAUTH_LIB_DIR', dirname(__FILE__).'/lib/Opauth/');

/**
* Load config
*/
if (!file_exists(CONF_FILE)){
	trigger_error('Config file missing at '.CONF_FILE, E_USER_ERROR);
	exit();
}
require CONF_FILE;

/**
 * Instantiate Opauth with the loaded config but not run automatically
 */
require OPAUTH_LIB_DIR.'Opauth.php';
$Opauth = new Opauth( $config, false );

	
/**
* Fetch auth response, based on transport configuration for callback
*/
$response = null;

switch($Opauth->env['callback_transport']){	
	case 'session':
		session_start();
		$response = $_SESSION['opauth'];
		unset($_SESSION['opauth']);
		break;
	case 'post':
		$response = unserialize(base64_decode( $_POST['opauth'] ));
		break;
	case 'get':
		$response = unserialize(base64_decode( $_GET['opauth'] ));
		break;
	default:
		echo '<strong style="color: red;">Error: </strong>Unsupported callback_transport.'."<br>\n";
		break;
}

/**
 * Check if it's an error callback
 */
if (array_key_exists('error', $response)){
	echo '<strong style="color: red;">Authentication error: </strong> Opauth returns error auth response.'."<br>\n";
}

/**
 * Auth response validation
 * 
 * To validate that the auth response received is unaltered, especially auth response that 
 * is sent through GET or POST.
 */
else{
	if (empty($response['auth']) || empty($response['timestamp']) || empty($response['signature']) || empty($response['auth']['provider']) || empty($response['auth']['uid'])){
		echo '<strong style="color: red;">Invalid auth response: </strong>Missing key auth response components.'."<br>\n";
	}
	elseif (!$Opauth->validate(sha1(print_r($response['auth'], true)), $response['timestamp'], $response['signature'], $reason)){
		echo '<strong style="color: red;">Invalid auth response: </strong>'.$reason.".<br>\n";
	}
	else{
		#echo '<strong style="color: green;">OK: </strong>Auth response is validated.'."<br>\n";
		/**
		 * It's all good. Go ahead with your application-specific authentication logic
		 */
		$conexion = AbrirMe();
		
		$authQuote = $response['auth'];
		$infoQuote = $response['auth']['info'];
		$rawQuote = $response['auth']['raw'];
		$fechaL = date("Y-m-d");
		
		$sql = mysql_query("INSERT INTO kindleUser (uid,nameu,emailu,imageu,provider,linkprovider,bioprovider,quotesprovider,fechaprovider,ref1) VALUES ('$authQuote[uid]','$infoQuote[name]','$infoQuote[email]','$infoQuote[image]', '$authQuote[provider]','$rawQuote[link]','$rawQuote[bio]','$rawQuote[quotes]','$fechaL','.')");
		
		
		$_SESSION["UID"] = $authQuote['uid'];
        $_SESSION["NAMEU"] = $infoQuote['name'];
        $_SESSION["EMAILU"] = utf8_decode($infoQuote['email']);
		$_SESSION["IMAGEU"] = $infoQuote['image'];
		$_SESSION["ACT"] = 1;
		$setCookie = session_set_cookie_params (18000);
			
	$subtituloHead = "Welcome";
	$descriptionHead = "A easy way to manage and share your Kindle Clippings";
?>
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"/>
		<title><?php echo $tituloHead; ?> :: <?php echo $subtituloHead; ?></title>

		<meta http-equiv="Description" content="<?php echo $descriptionHead; ?>" />
		<meta name="author" content="Boris Sanchez Molano" />
		<meta name="date" content="2012-09-19" />
		<meta name="owner" content="Kuote.us" />
		<meta name="viewport" content="width=device-width,initial-scale=1">	
		<!-- Estilos CSS -->
		<link rel="stylesheet" href="<?php echo $host; ?>css/frontstyles.css" type="text/css"/>
	</head>
	<body>
	<div id="wrap">
		<?php include("../header.php"); ?> 
		<div id="main">
			<div id="containertop">
				  <h1> A easy way to manage and share your Kindle Clippings </h1>
					<img src="<?php echo $host; ?>images/kuoteWelcome.png" border="0" align="right">
			</div>
		</div>
		<?php include("../foot.php"); ?>
	</div>
	</body>
	</html>
	<?php
	}
}
?>
<script type="text/javascript">
	function delayer(){
		window.location = "../index.php"
	}
	setTimeout('delayer()', 1000)
</script>
