$(document).ready(function () {
   // sin
    if (screen.width < 800) {
      $(".sizeNoSee").addClass("oculto");
    }
  
  $(".partes").hide();
  $("#paso1").show();
  

    // Initialize tooltip component
  $(function () {
    $('[data-toggle="tooltip"]').tooltip();
  });
  
  // Initialize popover component
  $(function () {
    $('[data-toggle="popover"]').popover();
  });
  
  
    $('body').on('click', '.pasos', function() {
        var idBox = $(this).attr("tabindex");
        $(".partes").hide();
        $("#paso" + idBox).show();
    });
    
    
  
  $(".tsugi1").click(function () {
    var idP = $("#bow").attr("revali");
    next1(idP);
  });
  
    $(".daruk").click(function () {
    var idP = $("#bow").attr("revali");
    guardar(idP);
  });
  
  
  
  /* Paso 1 */
  function next1(idProyWQ) {
    $("#titulo").removeClass("input-alerta");
    $("#ms-titulo").addClass("oculto");
  
    $("#cbx_materia").removeClass("input-alerta");
    $("#ms-area").addClass("oculto");
  
    $("#cbx_asignatura").removeClass("input-alerta");
    $("#ms-asignatura").addClass("oculto");
  
    $("#ms-edad").addClass("oculto");
  
    /* Para obtener el valor */
    var estadoTitulo = $("#titulo").val();
    var idArea = $("#cbx_materia").val();
    var idAsig = $("#cbx_asignatura").val();
    var edades = validadorEdad();
  
    if (estadoTitulo == "") {
      $("#titulo").addClass("input-alerta");
      $("#ms-titulo").removeClass("oculto");
      $("#titulo").focus();
      vali1 = 0;
    } else {
      vali1 = 1;
    }
  
    if (idArea == 0) {
      $("#cbx_materia").addClass("input-alerta");
      $("#ms-area").removeClass("oculto");
      $("#cbx_materia").focus();
      vali2 = 0;
    } else {
      vali2 = 1;
    }
  
    if (idAsig == 0) {
      $("#cbx_asignatura").addClass("input-alerta");
      $("#ms-asignatura").removeClass("oculto");
      $("#cbx_asignatura").focus();
      vali3 = 0;
    } else {
      vali3 = 1;
    }
  
    if (edades == 0) {
      $("#ms-edad").removeClass("oculto");
      vali4 = 0;
    } else {
      vali4 = 1;
    }
  
    if (vali1 == 1 && vali2 == 1 && vali3 == 1 && vali4 == 1) {

      $("#paso2").show();
      $("#errorTitulo").remove();
      $("#errorMateria").remove();
      $("#errorAsignatura").remove();
      $("#errorEdad").remove();
  
      var titulo = $("#titulo").val();
  
      var arregloEdades = $('[name="edad[]"]:checked')
        .map(function () {
          return this.value;
        })
        .get();
  
      edad = arregloEdades.join(",");
        $(".partes").hide();
         $("#paso2").show();

    }
  
    /* Valida el check de edad */
    function validadorEdad() {
      var vali = 0;
      for (var i = 1; i <= 7; i++) {
        if ($("#edad" + i).is(":checked")) {
          vali += 1;
        }
      }
      /* console.log(vali); */
      return vali;
    }
  }
  /* Fin Paso 1 */
  
   /* Inicio funcion que guarda el proyecto */
  function guardar(idProyWQ) {
    var titulo = $("#titulo").val();
    var area = $("#cbx_materia").val();
    var asignatura = $("#cbx_asignatura").val();
    var descripcion = CKEDITOR.instances["descripcion"].getData();
    var evaluacion = CKEDITOR.instances["evaluacion"].getData();

    var arregloEdades = $('[name="edad[]"]:checked')
      .map(function () {
        return this.value;
      })
      .get();
  
    edad = arregloEdades.join(",");
    //console.table(edad);
  

    /*hacemos ajax*/
    $.ajax({
      type: "POST",
      url: "includes/saveRubrica.php",
  
      data: {
        idProyWQ: idProyWQ,
        titulo: titulo,
        area: area,
        asignatura: asignatura,
        descripcion: descripcion,
        evaluacion: evaluacion,
        edad: edad,
      },
    })
      .done(function (resultado) {
        /*una vez realizada la busqueda envia los resultados la etiequeta que tenga el id result*/
        swal(
          "La Rubrica fue guardada!",
          "Puedes continuar editando si deseas! ",
          "success"
        );
      })
      .fail(function () {
        /*si la funcion no arroja resultado envia un aler de error*/
        alert("Hubo un error :(");
      });
  }
  /* Fin funcion que guarda el proyecto */

    
});