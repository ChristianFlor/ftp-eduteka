<?php
require('../config.php');
require_once('includes/funciones.php');

(isset($idU)) ? '' : header('Location: '.$serverName);

$token = $_POST['token'];
function getCaptcha($token)
{
    $response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=6LdbmpkeAAAAAIyw0tUdmzsitOFwJ5A3eNEjP7Uw&response=" . $token);
    $datos = json_decode($response, true);
    return $datos;
}

$datos = getCaptcha($token);

// Tema de la rúbrica
$temas = $_POST['pregunta'];
if(strlen($temas)>1){
    $temasAdd = " para el siguiente tema: $temas;";
 }
 

// Objetivos
$objetivo = $_POST['objetivo'];
if(strlen($objetivo)>1){
    $objAdd = " que tiene los siguientes objetivos de aprendizaje: $objetivo";
 } else {
    $objAdd = " creando objetivos de aprendizaje adecuados para el tema.";
 }
 

// area académica
$aged = implode(",", $_POST[edad]);
$newEdad = "'" . $aged . "'";
$edadMax = max($_POST[edad]);
$edadGPT .= verEdad($edadMax);

if($edadMax!=""){
    $edadAdd = "; la rúbrica debe ser acorde a la edad de $edadGPT.";
}


$areaID = $_POST['cbx_materia'];
$nArea = nombreAreaId($areaID);
$nombreArea = $nArea['nombre'];


$asignaturaID = $_POST['cbx_asignatura'];
$nAsignatura = datosAsignatura($asignaturaID);
$nombreAsignatura = "de la asignatura ".$nAsignatura['nombre'];

if($areaID>19){
        $tipoDocente = "¨Profesor de educación superior";
    } else {
        $tipoDocente = "¨Profesor de colegio";
    }

// Criterios de evaluacion
$criterios = " debe ser detallada y coherente con los objetivos de la tarea o proyecto. ";

$niveles = $_POST['niveles'];
if($niveles==3){ $tipoNivel = "3 niveles de desempeño, la rúbrica debe tener 4 columnas en la primera los cíterios de evaluación y en las esta escala de valoración Excelente, Bueno, Bajo."; }
elseif($niveles==4){$tipoNivel =  "4 niveles de desempeño, la rúbrica debe tener 5 columnas en la primera los cíterios de evaluación y en las siguientes esta escala de valoración Excelente, Bueno, Aceptable, Bajo."; }
elseif($niveles==5){ $tipoNivel = "5 niveles de desempeño, la rúbrica debe tener 6 columnas en la primera los cíterios de evaluación y en las siguientes esta escala de valoración Excelente, Sobresaliente, Bueno, Aceptable, Bajo."; }
else { $tipoNivel = "4 niveles de desempeño, la rúbrica debe tener la siguiente escala de valoración Excelente, Bueno, Aceptable, Bajo."; }


// Tipos de Rúbricas
$modoR = $_POST['modoRubrica'];

    if ($modoR == "RA") {  
        $modoRub = "Rúbrica analítica"; 
        $modCar = " Evalúa cada criterio de forma individual para obtener una visión detallada de las fortalezas y debilidades del estudiante en cada aspecto evaluado, se definen los criterios de evaluación y se describen $tipoNivel";  
        
    }
    elseif ($modoR == "RH") { 
        $modoRub =  "Rúbrica holística"; 
        $modCar = "    evalúa el trabajo en su conjunto y asigna un solo  criterio para cada aspecto a valorar demostrado por los estudiantes; la rúbrica tiene 3 columnas, en la primera se describen los aspectos a evaluar, en la segunda los criterios de valoración y la tercera en blanco para dar retroalimentación docente.";
      
    }
    elseif ($modoR == "RV") { 
        $modoRub =  "Rúbrica de lista de verificación"; 
        $modCar = " realizar una lista de elementos que deben estar presentes en el trabajo del estudiante y se evalúan con sí o no si, se cumplen o no."; 
    }
    elseif ($modoR == "RE") { 
        $modoRub =  "Rúbrica escalar"; 
        $modCar = " Evalúa el trabajo en una escala numérica, en la que se asigna una puntuación a cada criterio y se obtiene una calificación final sumando las puntuaciones, debe tener 3 columnas: aspectos a evaluar, criterios de evaluación y puntuación; se usa la siguiente escala de valoración: escala de porcentajes que va del 0% al 100%, donde el nivel de desempeño excelente se asigna un 90% o más, bueno 80% y más, aceptable 50% y más, pobre menos del 50%. "; 
        }
    elseif ($modoR == "RO") { 
        $modoRub =  "Rúbrica de observación"; 
        $modCar = " se describen los comportamientos o habilidades que deben ser observados y se evalúan utilizando una escala de puntuación, esta rúbrica se utiliza para evaluar el comportamiento o habilidades de una persona en situaciones específicas y en tiempo real,  debe tener la siguiente escala de valoración: se asigna una escala numérica de 1 a 5, donde 1 indica que el desempeño es muy pobre y 5 indica que el desempeño es excelente."; 
        }
    elseif ($modoR == "AE") { 
        $modoRub =  "Rúbrica de autoevaluación y coevaluación"; 
        $modCar = " es un tipo de herramienta de evaluación que se utiliza para que los estudiantes evalúen su propio trabajo o el trabajo de sus compañeros, respectivamente, es un tipo de herramienta de evaluación que se utiliza para que los estudiantes evalúen su propio trabajo o el trabajo de sus compañeros, debe tener la siguiente escala de valoración de dos dimensiones: se indica un desempeño excelente y el nivel de desempeño pobre y una columna para comentario "; 
        }
    elseif ($modoR == "PU") { 
        $modoRub =  "Rúbrica de punto único"; 
        $modCar = " es un tipo de herramienta de evaluación que describen los desempeños que un estudiante debe cumplir para completar una tarea; sin embargo, posibilita la retroalimentación abierta mediante la descripción lo que el estudiante hizo bien y aquello que puede mejorar. tiene 3 columnas , en la 1 los criterios a evaluar, la 2 los aspectos a mejorar y la 3 los aspectos a mejorar."; 
        }
     


$largoAct = 4000;
    
    // OpenAI
    $apiKey = "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";
    $url = "https://api.openai.com/v1/chat/completions";
    
      $preguntaSys = "";
    
    $preguntaDef = "
    Eres un $tipoDocente del area $nombreArea, vas a crear una rúbrica con las siguientes caracteristicas:
    - Crear una $modoRub para evaluar $temasAdd $nombreAsignatura; $objAdd; $edadAdd.
    - Esta Rúbrica $modCar    
    - La rúbrica  Los  criterios deben ser claros, bien diferenciados y coherentes con los objetivos de la tarea o proyecto,
    - La rúbrica es mayor a 3800 palabras, se despliega en forma de tabla
    -  genera la respuesta mostrando el título en H1, la descripción de la rubríca en <span>   y la rúbrica en lenguaje de marcado HTML usando <table> para la rúbrica.   
    ";
    
    $preguntaDef = $preguntaDef;
    
    $data = array(
        "model" => "gpt-3.5-turbo-16k-0613",   
        
            "messages" => array(
                array("role" => "system", "content" => $preguntaSys),
                array("role" => "user", "content" => $preguntaDef)
            )            
    );
    
    $headers = array(
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey
    );
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    
    $response = curl_exec($ch);
    
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    } else {
    
    $decodedResponse = json_decode($response, true);
    $ResponseFinal = $decodedResponse['choices'][0]['message']['content'];
    $totalTokens = $decodedResponse[usage][total_tokens];
    
     
    $patron = "/(<h1>[^<]+<\/h1>)/i";
    $separadores = preg_split($patron, $ResponseFinal, -1, PREG_SPLIT_DELIM_CAPTURE);
    $resultado = array();
    
    foreach ($separadores as $separador) {
      if (strpos($separador, '<h1>') !== false) {
        array_push($resultado, $separador);
      } else {
        $ultimo = count($resultado) - 1;
        $resultado[$ultimo] .= $separador;
      }
    }
    

    if(strlen($resultado[0])>3){
        $contenidoTitulo = strip_tags($resultado[0]);        
     }else {
        $contenidoTitulo = strip_tags($resultado[-1]);
     }
     
     $rubricaFinal = $resultado[1];
     
     $inicio = strpos($rubricaFinal, "<span>") + strlen("<span>");
    $fin = strpos($rubricaFinal, "</span>");
    $descripcion = substr($rubricaFinal, $inicio, $fin - $inicio);
    
     
     if ($datos['success'] == 1 && $datos['score'] >= 0.5) {
            if ((isset($idU) || $idU != "" || $idU != null)&($totalTokens>100)) {
     
                 if(strlen($rubricaFinal)>100){
                 
                       require('conexion.php');
                        $conexion->set_charset("utf8");
                        $conexion->select_db("edtk_rubrik");
                       
                        $query = "INSERT INTO `rubricas`(`idR`, `area`, `asignatura`, `edad`, `titulo`, `descripcion`, `evaluacion`, `fechaCreacion`) VALUES (null, '$areaID', '$asignaturaID', '$edadMax', '$contenidoTitulo', '$descripcion', '$rubricaFinal', NOW())";
                        $result = mysqli_query($conexion, $query);
                        $idR = mysqli_insert_id($conexion);
                        
                        $query = "INSERT INTO `rubusuario`(`idEst`, `idU`, `idR`, `tipo`, `token`, `fechaP`) VALUES (null, '$idU', '$idR', '$modoR', '$totalTokens',NOW())";
                        $result = mysqli_query($conexion, $query);                           
                        mysqli_close($conexion);
                        
                        $_SESSION["idR"] = $idR;
                        
                        logCrear($idU,$idR,9,$totalTokens);
                        
                      header("location:verRubrica.php"); 
                }else{
                    logCrear($idU,$idR,13,$totalTokens);
                   header("location:https://edtk.co/rubrik/error.php");  
                } 
            }           
        } else {
           header("location:index.php");
        }      
          
        /*  print "$preguntaDef<hr>";    
            print_r($resultado);
            print "<hr>Tokens: $totalTokens <hr>";    */
    
    curl_close($ch);
}
?>