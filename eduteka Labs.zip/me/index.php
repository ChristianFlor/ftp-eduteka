<?php
require_once('../config.php');
header('Location: '.$serverName .'me/ingresar.php')

?>