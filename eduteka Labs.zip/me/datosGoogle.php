<?php
  
  $clientID = '92404003350-oe449js9ub29luc40dnp164ricp1s45t.apps.googleusercontent.com';
  $clientSecret = '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';
  $redirectUri = 'https://edtk.co/me/validador.php';  
 
?>